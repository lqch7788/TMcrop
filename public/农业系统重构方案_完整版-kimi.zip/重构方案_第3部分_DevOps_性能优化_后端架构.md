# 农业系统企业级重构方案 — 第3部分：DevOps + 性能优化 + 后端架构升级 + 验收清单

**适用仓库**: `https://github.com/lqch7788/TMcrop` (planting-management 分支)  
**预计工期**: 本部分约 10-14 天  
**编写日期**: 2026-05-07

> **注意**: 这是重构方案的第3部分（共3部分），包含阶段5（DevOps与CI/CD）、阶段6（性能优化）、阶段7（后端架构升级）、验收检查清单、常见陷阱与注意事项。
> - 第1部分：执行前准备 + 阶段1（基础工程化）+ 阶段2（安全加固）
> - 第2部分：阶段3（架构重构）+ 阶段4（测试体系）

---

## 📋 第3部分目录

1. [阶段5：DevOps与CI/CD (P1)](#五阶段5devops与cicd-p1)
2. [阶段6：性能优化 (P2)](#六阶段6性能优化-p2)
3. [阶段7：后端架构升级 (P1-P2)](#七阶段7后端架构升级-p1-p2)
4. [验收检查清单](#八验收检查清单)
5. [常见陷阱与注意事项](#九常见陷阱与注意事项)

---

## 五、阶段5：DevOps与CI/CD (P1)

**目标**: 实现自动化构建、测试、部署。  
**预计工时**: 2-3 天  
**依赖阶段**: 阶段4（测试体系建立后才能 CI）

---

### 任务 5.1：GitHub Actions CI/CD

**文件**: `.github/workflows/ci.yml`（新建）

```yaml
name: CI/CD

on:
  push:
    branches: [main, planting-management, refactor/enterprise-grade]
  pull_request:
    branches: [main, planting-management]

jobs:
  lint-and-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install frontend dependencies
        run: npm ci

      - name: Lint
        run: npm run lint

      - name: Type check
        run: npx tsc --noEmit

      - name: Build
        run: npm run build

      - name: Test
        run: npm run test:coverage

      - name: Upload coverage
        uses: codecov/codecov-action@v3
        with:
          files: ./coverage/lcov.info

  backend-test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install backend dependencies
        run: |
          cd server
          npm ci

      - name: Test backend
        run: |
          cd server
          npm test
```

---

### 任务 5.2：Docker 容器化

**文件**: `docker/Dockerfile.frontend`（新建）

```dockerfile
FROM node:20-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci

COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY docker/nginx.conf /etc/nginx/conf.d/default.conf

EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
```

**文件**: `docker/Dockerfile.backend`（新建）

```dockerfile
FROM node:20-alpine

WORKDIR /app

COPY server/package*.json ./
RUN npm ci --only=production

COPY server/dist ./

EXPOSE 3001

ENV NODE_ENV=production

CMD ["node", "index.js"]
```

**文件**: `docker/docker-compose.yml`（新建）

```yaml
version: '3.8'

services:
  frontend:
    build:
      context: ..
      dockerfile: docker/Dockerfile.frontend
    ports:
      - "80:80"
    depends_on:
      - backend

  backend:
    build:
      context: ..
      dockerfile: docker/Dockerfile.backend
    ports:
      - "3001:3001"
    environment:
      - NODE_ENV=production
      - JWT_SECRET=${JWT_SECRET}
      - DB_PATH=/data/app.db
    volumes:
      - ./data:/data

  redis:
    image: redis:7-alpine
    ports:
      - "6379:6379"
```

---

### 任务 5.3：环境变量管理

**文件**: `.env.example`（新建，提交到 Git）

```
# 前端
VITE_API_URL=http://localhost:3001/api
VITE_APP_NAME=TMcrop

# 后端
NODE_ENV=development
PORT=3001
JWT_SECRET=change-this-in-production
DB_PATH=./data/app.db
CORS_ORIGIN=http://localhost:5173

# Redis（可选）
REDIS_URL=redis://localhost:6379
```

**注意**: `.env.local` 已存在于 `.gitignore`，本地开发使用。

---

### 阶段5 验收清单

| 检查项 | 命令/方法 | 通过标准 |
|--------|----------|---------|
| GitHub Actions | Push 到分支 | CI 全绿 |
| Docker 构建 | `docker-compose up --build` | 容器启动正常 |
| 健康检查 | `curl http://localhost:3001/api/health` | 返回 200 |

---

## 六、阶段6：性能优化 (P2)

**目标**: 提升大表格渲染性能，实现代码分割。  
**预计工时**: 3-4 天  
**依赖阶段**: 阶段3（组件拆分后才能有效优化）

---

### 任务 6.1：虚拟滚动优化大表格

**安装**: `npm install @tanstack/react-virtual`

**使用示例**:

```typescript
import { useVirtualizer } from '@tanstack/react-virtual';
import { useRef } from 'react';

function VirtualTable({ data }: { data: Array<Record<string, unknown>> }) {
  const parentRef = useRef<HTMLDivElement>(null);

  const virtualizer = useVirtualizer({
    count: data.length,
    getScrollElement: () => parentRef.current,
    estimateSize: () => 50,
    overscan: 5,
  });

  return (
    <div ref={parentRef} style={{ height: '600px', overflow: 'auto' }}>
      <div style={{ height: `${virtualizer.getTotalSize()}px`, position: 'relative' }}>
        {virtualizer.getVirtualItems().map((virtualItem) => (
          <div
            key={virtualItem.key}
            style={{
              position: 'absolute',
              top: 0,
              left: 0,
              width: '100%',
              height: `${virtualItem.size}px`,
              transform: `translateY(${virtualItem.start}px)`,
            }}
          >
            {data[virtualItem.index].batchCode as string}
          </div>
        ))}
      </div>
    </div>
  );
}
```

---

### 任务 6.2：代码分割

```typescript
// src/App.tsx
import { lazy, Suspense } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { LoadingSpinner } from './shared/ui/LoadingSpinner';

const Dashboard = lazy(() => import('./features/dashboard/DashboardPage'));
const Production = lazy(() => import('./features/production/ProductionPage'));
const TechSolution = lazy(() => import('./features/techSolution/TechSolutionPage'));
const PurchasePlan = lazy(() => import('./features/purchasePlan/PurchasePlanPage'));

function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<LoadingSpinner />}>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/production" element={<Production />} />
          <Route path="/tech-solutions" element={<TechSolution />} />
          <Route path="/purchase-plans" element={<PurchasePlan />} />
        </Routes>
      </Suspense>
    </BrowserRouter>
  );
}
```

---

### 任务 6.3：React Query 数据缓存

**安装**: `npm install @tanstack/react-query`

**配置**:
```typescript
// src/App.tsx
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000,
      gcTime: 10 * 60 * 1000,
      retry: 2,
      refetchOnWindowFocus: true,
    },
  },
});

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      {/* 路由 */}
    </QueryClientProvider>
  );
}
```

**使用**:
```typescript
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';

export function useProductionPlans() {
  const queryClient = useQueryClient();

  const { data: batches, isLoading } = useQuery({
    queryKey: ['production-plans'],
    queryFn: () => apiClient.get('/production/plans'),
  });

  const create = useMutation({
    mutationFn: (data: unknown) => apiClient.post('/production/plans', data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['production-plans'] });
    },
  });

  return { batches, isLoading, create };
}
```

---

## 七、阶段7：后端架构升级 (P1-P2)

**目标**: 将后端从 Router 直接操作数据库，升级为分层架构。  
**预计工时**: 5-7 天  
**依赖阶段**: 阶段2（类型安全、认证中间件已就绪）

---

### 任务 7.1：创建分层目录结构

```bash
cd server/src
mkdir -p controllers services repositories models middleware utils
```

---

### 任务 7.2：Repository 层（数据访问）

**文件**: `server/src/repositories/productionPlan.repository.ts`（新建）

```typescript
import { db } from '../db';

export interface ProductionPlanRecord {
  id: string;
  batch_code: string;
  crop_name: string;
  target_quantity: number;
  status: string;
  created_at: string;
}

export class ProductionPlanRepository {
  async findAll(options?: { status?: string; limit?: number; offset?: number }): Promise<ProductionPlanRecord[]> {
    let sql = 'SELECT * FROM production_plans WHERE 1=1';
    const params: unknown[] = [];

    if (options?.status) {
      sql += ' AND status = ?';
      params.push(options.status);
    }
    sql += ' ORDER BY created_at DESC';
    if (options?.limit) { sql += ' LIMIT ?'; params.push(options.limit); }
    if (options?.offset) { sql += ' OFFSET ?'; params.push(options.offset); }

    return db.all<ProductionPlanRecord[]>(sql, params);
  }

  async findById(id: string): Promise<ProductionPlanRecord | undefined> {
    return db.get<ProductionPlanRecord>('SELECT * FROM production_plans WHERE id = ?', [id]);
  }

  async create(data: Omit<ProductionPlanRecord, 'id' | 'created_at'>): Promise<ProductionPlanRecord> {
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    await db.run(
      `INSERT INTO production_plans (id, batch_code, crop_name, target_quantity, status, created_at)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [id, data.batch_code, data.crop_name, data.target_quantity, data.status, now]
    );
    return this.findById(id) as Promise<ProductionPlanRecord>;
  }

  async update(id: string, data: Partial<ProductionPlanRecord>): Promise<ProductionPlanRecord> {
    const fields = Object.keys(data);
    const values = Object.values(data);
    const setClause = fields.map(f => `${f} = ?`).join(', ');
    await db.run(`UPDATE production_plans SET ${setClause} WHERE id = ?`, [...values, id]);
    return this.findById(id) as Promise<ProductionPlanRecord>;
  }

  async delete(id: string): Promise<void> {
    await db.run('DELETE FROM production_plans WHERE id = ?', [id]);
  }
}

export const productionPlanRepository = new ProductionPlanRepository();
```

---

### 任务 7.3：Service 层（业务逻辑）

**文件**: `server/src/services/productionPlan.service.ts`（新建）

```typescript
import { ProductionPlanRepository, productionPlanRepository } from '../repositories/productionPlan.repository';
import { AppError } from '../utils/AppError';

export class ProductionPlanService {
  constructor(private repository: ProductionPlanRepository = productionPlanRepository) {}

  async getAll(query: { status?: string; page?: number; pageSize?: number } = {}) {
    const limit = query.pageSize || 10;
    const offset = ((query.page || 1) - 1) * limit;
    const [plans, total] = await Promise.all([
      this.repository.findAll({ status: query.status, limit, offset }),
      this.count(query.status),
    ]);
    return { plans, total, page: query.page || 1, pageSize: limit };
  }

  async count(status?: string): Promise<number> {
    // 通过 Repository 或单独查询实现
    return 0;
  }

  async getById(id: string) {
    const plan = await this.repository.findById(id);
    if (!plan) throw new AppError('Production plan not found', 404);
    return plan;
  }

  async create(data: { batchCode: string; cropName: string; targetQuantity: number }) {
    const existing = await this.repository.findAll();
    if (existing.some(p => p.batch_code === data.batchCode)) {
      throw new AppError('Batch code already exists', 409);
    }
    return this.repository.create({
      batch_code: data.batchCode,
      crop_name: data.cropName,
      target_quantity: data.targetQuantity,
      status: 'draft',
    });
  }

  async update(id: string, data: Partial<{ batchCode: string; cropName: string; targetQuantity: number; status: string }>) {
    await this.getById(id);
    const updates: Record<string, unknown> = {};
    if (data.batchCode) updates.batch_code = data.batchCode;
    if (data.cropName) updates.crop_name = data.cropName;
    if (data.targetQuantity) updates.target_quantity = data.targetQuantity;
    if (data.status) updates.status = data.status;
    return this.repository.update(id, updates);
  }

  async delete(id: string) {
    const plan = await this.getById(id);
    if (plan.status === 'active') {
      throw new AppError('Cannot delete active plan', 400);
    }
    await this.repository.delete(id);
  }
}

export const productionPlanService = new ProductionPlanService();
```

---

### 任务 7.4：Controller 层（HTTP 处理）

**文件**: `server/src/controllers/productionPlan.controller.ts`（新建）

```typescript
import { Request, Response, NextFunction } from 'express';
import { productionPlanService } from '../services/productionPlan.service';

export class ProductionPlanController {
  async getAll(req: Request, res: Response, next: NextFunction) {
    try {
      const { status, page, pageSize } = req.query;
      const result = await productionPlanService.getAll({
        status: status as string,
        page: page ? parseInt(page as string) : undefined,
        pageSize: pageSize ? parseInt(pageSize as string) : undefined,
      });
      res.json(result);
    } catch (err) { next(err); }
  }

  async getById(req: Request, res: Response, next: NextFunction) {
    try {
      const plan = await productionPlanService.getById(req.params.id);
      res.json(plan);
    } catch (err) { next(err); }
  }

  async create(req: Request, res: Response, next: NextFunction) {
    try {
      const plan = await productionPlanService.create(req.body);
      res.status(201).json(plan);
    } catch (err) { next(err); }
  }

  async update(req: Request, res: Response, next: NextFunction) {
    try {
      const plan = await productionPlanService.update(req.params.id, req.body);
      res.json(plan);
    } catch (err) { next(err); }
  }

  async delete(req: Request, res: Response, next: NextFunction) {
    try {
      await productionPlanService.delete(req.params.id);
      res.status(204).send();
    } catch (err) { next(err); }
  }
}

export const productionPlanController = new ProductionPlanController();
```

---

### 任务 7.5：重构路由文件

**文件**: `server/src/routes/productionPlan.ts`（重写）

```typescript
import { Router } from 'express';
import { productionPlanController } from '../controllers/productionPlan.controller';
import { validateBody } from '../middleware/validateRequest';
import { CreatePlanSchema } from '../models/schemas';

const router = Router();

router.get('/plans', productionPlanController.getAll);
router.get('/plans/:id', productionPlanController.getById);
router.post('/plans', validateBody(CreatePlanSchema), productionPlanController.create);
router.put('/plans/:id', productionPlanController.update);
router.delete('/plans/:id', productionPlanController.delete);

export default router;
```

---

### 任务 7.6：统一日志系统

**安装**: `npm install winston`

**文件**: `server/src/utils/logger.ts`（新建）

```typescript
import winston from 'winston';

const { combine, timestamp, json, errors } = winston.format;

export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  defaultMeta: { service: 'tmcrop-api' },
  format: combine(timestamp(), errors({ stack: true }), json()),
  transports: [
    new winston.transports.Console(),
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' }),
  ],
});
```

**在错误处理中间件中使用**:
```typescript
import { logger } from '../utils/logger';

export function errorHandler(err: Error, req: Request, res: Response, next: NextFunction) {
  logger.error(err.message, { stack: err.stack, path: req.path });
  // ... 其余错误处理
}
```

---

## 八、验收检查清单

### 8.1 阶段1验收

- [ ] `tsconfig.app.json` 中 `strict: true`
- [ ] `npm run build` 返回 0 errors
- [ ] `eslint.config.js` 中 `@typescript-eslint/no-explicit-any: 'error'`
- [ ] `npm run lint` 返回 0 errors
- [ ] `.prettierrc` 存在且已格式化全部代码
- [ ] 权限控制已恢复，不同角色显示不同按钮

### 8.2 阶段2验收

- [ ] 前端表单提交非法数据时显示 Zod 验证错误
- [ ] 后端 POST 非法数据返回 400 + 错误详情
- [ ] 不带 Token 请求返回 401
- [ ] 快速请求 101 次第 101 次返回 429
- [ ] 触发未处理异常返回 500 + 友好消息

### 8.3 阶段3验收

- [ ] ProductionPage.tsx < 300 行
- [ ] TechSolutionPage.tsx < 300 行
- [ ] PurchasePlanPage.tsx < 300 行
- [ ] 功能正常（增删改查、导出、审批）

### 8.4 阶段4验收

- [ ] `npm test` 全部通过
- [ ] `npm run test:coverage` lines >= 80%
- [ ] 至少 20 个测试用例覆盖核心功能

### 8.5 阶段5验收

- [ ] Push 代码后 GitHub Actions 全绿
- [ ] `docker-compose up --build` 正常启动
- [ ] `curl http://localhost/api/health` 返回 200

### 8.6 阶段6验收

- [ ] 1000 条数据表格滚动流畅
- [ ] Lighthouse 性能评分 >= 80
- [ ] 首屏加载时间 < 3 秒

### 8.7 阶段7验收

- [ ] 后端分层：Controller → Service → Repository
- [ ] 所有路由使用分层架构
- [ ] 统一错误处理和日志记录

---

## 九、常见陷阱与注意事项

### 9.1 严格模式迁移陷阱

| 陷阱 | 解决方案 |
|------|---------|
| `any` 泛滥 | 逐个文件修复，先修 Service 层再修组件 |
| `null` 检查爆炸 | 使用可选链 `?.` 和非空断言 `!`（谨慎） |
| 第三方库无类型 | `@types/xxx` 或 `.d.ts` 声明文件 |
| 构建时间变长 | 正常现象，严格模式会检查更多 |

### 9.2 组件拆分陷阱

| 陷阱 | 解决方案 |
|------|---------|
| 拆分后 props drilling 严重 | 使用 React Context 或 Zustand |
| 拆分后数据流混乱 | 每个 Feature 维护自己的 Hook |
| 过度拆分 | 组件 < 50 行也可能过度，看逻辑内聚 |

### 9.3 测试编写陷阱

| 陷阱 | 解决方案 |
|------|---------|
| 测试依赖真实 API | 全部 mock，测试不应调真实后端 |
| 测试不独立 | 每个 `it` 独立，用 `beforeEach` 清理 |
| 覆盖率虚高 | 关注断言质量，不只是行数 |

### 9.4 安全陷阱

| 陷阱 | 解决方案 |
|------|---------|
| JWT Secret 硬编码 | 使用环境变量，生产环境随机生成 |
| CORS 配置为 `*` | 必须配置白名单 |
| 密码明文存储 | 必须用 bcrypt 哈希 |
| SQL 字符串拼接 | 全部参数化或使用 ORM |

---

## 附录：快速参考命令

```bash
# === 日常开发 ===
npm run dev          # 启动开发服务器
npm run build        # 生产构建
npm run lint         # 代码检查
npm run test         # 运行测试
npm run test:coverage # 覆盖率报告

# === 后端 ===
cd server && npm run dev    # 启动后端

# === Docker ===
docker-compose up --build   # 构建并启动全部服务
docker-compose down         # 停止服务

# === 数据库 ===
cd server && npx sqlite3 data/app.db  # 直接操作 SQLite
```

---

*方案基于*: 《Claude Code 专业开发手册》2.0 Pro Edition  
*适用仓库*: `https://github.com/lqch7788/TMcrop`  
*编写日期*: 2026-05-07  
*版本*: v1.0
