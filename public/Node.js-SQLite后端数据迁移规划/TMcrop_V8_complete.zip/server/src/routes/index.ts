/**
 * 路由汇总
 */

import { Router } from 'express';
import cropVarietyRouter from './cropVariety';
import inventoryRouter from './inventory';
import seedlingRouter from './seedling';
import seedSourceRouter from './seedSource';
import plantingRouter from './planting';
import harvestRouter from './harvest';
import supplierRouter from './supplier';
import cropInstanceRouter from './cropInstance';
import farmTaskRouter from './farmTask';
import inspectionRouter from './inspection';
import problemRouter from './problem';
import laborRouter from './labor';
import tempTaskRouter from './tempTask';
import purchasePlanRouter from './purchasePlan';
import materialRequestRouter from './materialRequest';
import basicDataRouter from './basicData';
import dictionaryRouter from './dictionary';
import authorityRouter from './authority';
import notificationRouter from './notification';
import approvalWorkflowRouter from './approvalWorkflow';
import approvalRouter from './approval';
import operationLogRouter from './operationLog';
import cropOrderRouter from './cropOrder';
import productionPlanRouter from './productionPlan';

// V8.0 新增路由
import staffRouter from './staff';
import basesRouter from './bases';
import companyGroupsRouter from './companyGroups';
import materialsRouter from './materials';
import materialReceivingRouter from './materialReceiving';
import materialUsageRouter from './materialUsage';
import materialReturnRouter from './materialReturn';
import farmActivitiesRouter from './farmActivities';
import plantingModesRouter from './plantingModes';
import dailyPlansRouter from './dailyPlans';
import monthlyPlansRouter from './monthlyPlans';
import indicatorsRouter from './indicators';
import productionRecordsRouter from './productionRecords';
import deviceManagementRouter from './deviceManagement';
import costAccountingRouter from './costAccounting';
import attendanceRouter from './attendance';
import leaveRouter from './leave';
import overtimeRouter from './overtime';
import recruitmentRouter from './recruitment';
import contractsRouter from './contracts';
import onboardingsRouter from './onboardings';
import resignationsRouter from './resignations';
import auditLogsRouter from './auditLogs';

const router = Router();

// 作物品种路由
router.use('/crop-varieties', cropVarietyRouter);

// 库存路由
router.use('/inventory', inventoryRouter);

// 育苗管理路由
router.use('/seedlings', seedlingRouter);

// 种源管理路由
router.use('/seed-sources', seedSourceRouter);

// 种植管理路由
router.use('/plantings', plantingRouter);

// 采收管理路由
router.use('/harvest', harvestRouter);

// 供应商路由
router.use('/suppliers', supplierRouter);

// 作物实例路由
router.use('/crop-instances', cropInstanceRouter);

// 农事任务路由
router.use('/farm-tasks', farmTaskRouter);

// 巡查记录路由
router.use('/inspections', inspectionRouter);

// 问题记录路由
router.use('/problems', problemRouter);

// 人工记录路由
router.use('/labor', laborRouter);

// 临时任务路由
router.use('/temp-tasks', tempTaskRouter);

// 采购计划路由
router.use('/purchase-plans', purchasePlanRouter);

// 物料申请路由
router.use('/material-requests', materialRequestRouter);

// 基础数据路由（部门/仓库/温室/职位/区域/地块/编码规则/通知渠道/通知规则等）
router.use('/basic-data', basicDataRouter);

// 数据字典路由
router.use('/dictionary', dictionaryRouter);

// 组织与权限路由
router.use('/authority', authorityRouter);

// 通知设置路由
router.use('/notifications', notificationRouter);

// 审批工作流路由
router.use('/approval-workflows', approvalWorkflowRouter);

// 审批单路由
router.use('/approvals', approvalRouter);

// 操作日志路由
router.use('/operation-logs', operationLogRouter);

// 订单路由
router.use('/crop-orders', cropOrderRouter);

// 生产计划路由
router.use('/production-plans', productionPlanRouter);

// ========== V8.0 新增路由注册 ==========
router.use('/staff', staffRouter);
router.use('/bases', basesRouter);
router.use('/company-groups', companyGroupsRouter);
router.use('/materials', materialsRouter);
router.use('/material-receiving', materialReceivingRouter);
router.use('/material-usage', materialUsageRouter);
router.use('/material-return', materialReturnRouter);
router.use('/farm-activities', farmActivitiesRouter);
router.use('/planting-modes', plantingModesRouter);
router.use('/daily-plans', dailyPlansRouter);
router.use('/monthly-plans', monthlyPlansRouter);
router.use('/indicators', indicatorsRouter);
router.use('/production-records', productionRecordsRouter);
router.use('/device-management', deviceManagementRouter);
router.use('/cost-accounting', costAccountingRouter);
router.use('/attendance', attendanceRouter);
router.use('/leave', leaveRouter);
router.use('/overtime', overtimeRouter);
router.use('/recruitment', recruitmentRouter);
router.use('/contracts', contractsRouter);
router.use('/onboardings', onboardingsRouter);
router.use('/resignations', resignationsRouter);
router.use('/audit-logs', auditLogsRouter);

// 健康检查
router.get('/health', (req, res) => {
  res.json({ success: true, message: 'API 服务正常运行' });
});

export default router;
