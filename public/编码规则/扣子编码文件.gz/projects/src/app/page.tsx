'use client';

import { useState, useMemo, useCallback } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Separator } from '@/components/ui/separator';
import { Label } from '@/components/ui/label';
import { 
  Building2, 
  Package, 
  Copy, 
  Check, 
  RefreshCw, 
  Search, 
  Info,
  Hash,
  Layers,
  ChevronRight,
  Sparkles,
  Download,
  FileSpreadsheet,
  Database,
  Table,
  FileText,
  ExternalLink
} from 'lucide-react';
import { toast } from 'sonner';
import {
  materialCategories,
  materialSubCategories,
  materialMinorCategories,
  supplierCategories,
  supplierSubCategories,
  supplierMinorCategories,
  encodingRules,
  getMaterialMinorCategories,
  getSupplierMinorCategories,
  parseMaterialCode,
  parseSupplierCode,
} from '@/lib/encoding-data';

// 编码记录类型
interface EncodingRecord {
  code: string;
  type: 'material' | 'supplier';
  mainName: string;
  subName: string;
  minorName: string;
  sequence: string;
  fullPath: string;
  createdAt: string;
}

// ==================== 资材编码生成器 ====================
function MaterialEncoder({ onGenerate }: { onGenerate: (record: EncodingRecord) => void }) {
  const [mainCategory, setMainCategory] = useState<string>('');
  const [subCategory, setSubCategory] = useState<string>('');
  const [minorCategory, setMinorCategory] = useState<string>('');
  const [sequence, setSequence] = useState<string>('001');
  const [copied, setCopied] = useState(false);
  const [searchMain, setSearchMain] = useState('');

  const subCategories = useMemo(() => {
    return mainCategory ? (materialSubCategories[mainCategory] || []) : [];
  }, [mainCategory]);

  const minorCategories = useMemo(() => {
    return mainCategory && subCategory ? getMaterialMinorCategories(mainCategory, subCategory) : [];
  }, [mainCategory, subCategory]);

  const generatedCode = useMemo(() => {
    if (!mainCategory || !subCategory || !minorCategory) return '';
    return `${mainCategory}${subCategory}${minorCategory}${sequence}`;
  }, [mainCategory, subCategory, minorCategory, sequence]);

  const handleMainChange = (value: string) => {
    setMainCategory(value);
    setSubCategory('');
    setMinorCategory('');
  };

  const handleSubChange = (value: string) => {
    setSubCategory(value);
    setMinorCategory('');
  };

  const handleCopy = async () => {
    if (generatedCode) {
      await navigator.clipboard.writeText(generatedCode);
      setCopied(true);
      toast.success('编码已复制到剪贴板');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleReset = () => {
    setMainCategory('');
    setSubCategory('');
    setMinorCategory('');
    setSequence('001');
  };

  const handleSave = () => {
    if (!generatedCode) return;
    
    const main = materialCategories.find(c => c.code === mainCategory);
    const sub = subCategories.find(c => c.code === subCategory);
    const minor = minorCategories.find(c => c.code === minorCategory);
    
    const record: EncodingRecord = {
      code: generatedCode,
      type: 'material',
      mainName: main?.name || '',
      subName: sub?.name || '',
      minorName: minor?.name || '',
      sequence,
      fullPath: `${main?.name} > ${sub?.name} > ${minor?.name}`,
      createdAt: new Date().toISOString(),
    };
    
    onGenerate(record);
    toast.success('编码已保存到记录列表');
  };

  const filteredMainCategories = useMemo(() => {
    if (!searchMain) return materialCategories;
    return materialCategories.filter(c => 
      c.name.toLowerCase().includes(searchMain.toLowerCase()) ||
      c.code.toLowerCase().includes(searchMain.toLowerCase()) ||
      c.english?.toLowerCase().includes(searchMain.toLowerCase())
    );
  }, [searchMain]);

  const getSelectedMain = () => materialCategories.find(c => c.code === mainCategory);
  const getSelectedSub = () => subCategories.find(c => c.code === subCategory);
  const getSelectedMinor = () => minorCategories.find(c => c.code === minorCategory);

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* 编码规则说明 */}
      <Card className="lg:col-span-2 border-green-200 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-green-700 dark:text-green-400">
            <Info className="h-5 w-5" />
            资材分类编码规则
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="border-green-300 text-green-700 dark:border-green-700 dark:text-green-400">
                结构
              </Badge>
              <code className="rounded bg-green-100 px-2 py-1 text-sm dark:bg-green-900/30">
                {encodingRules.material.structure}
              </code>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="border-green-300 text-green-700 dark:border-green-700 dark:text-green-400">
                示例
              </Badge>
              <code className="rounded bg-green-100 px-2 py-1 font-mono text-sm text-green-700 dark:bg-green-900/30 dark:text-green-400">
                {encodingRules.material.example}
              </code>
            </div>
          </div>
          <p className="mt-2 text-sm text-green-600 dark:text-green-400/80">
            {encodingRules.material.exampleDetail} → {encodingRules.material.example}
          </p>
        </CardContent>
      </Card>

      {/* 选择区域 */}
      <Card className="border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Package className="h-5 w-5 text-green-600" />
            分类配置
          </CardTitle>
          <CardDescription>选择资材分类层级</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* 大类 */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Layers className="h-4 w-4 text-green-600" />
              资材大类 <span className="text-red-500">*</span>
            </Label>
            <div className="relative mb-2">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="搜索大类..."
                value={searchMain}
                onChange={(e) => setSearchMain(e.target.value)}
                className="pl-9 border-green-200 focus:ring-green-500"
              />
            </div>
            <Select value={mainCategory} onValueChange={handleMainChange}>
              <SelectTrigger className="border-green-200 focus:ring-green-500">
                <SelectValue placeholder="选择资材大类" />
              </SelectTrigger>
              <SelectContent>
                <ScrollArea className="h-48">
                  {filteredMainCategories.map((c) => (
                    <SelectItem key={c.code} value={c.code}>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-green-600 w-8">{c.code}</span>
                        <span>{c.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </ScrollArea>
              </SelectContent>
            </Select>
            {getSelectedMain() && (
              <p className="text-xs text-muted-foreground">{getSelectedMain()?.english} - {getSelectedMain()?.description}</p>
            )}
          </div>

          {/* 中类 */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <ChevronRight className="h-4 w-4 text-green-600" />
              资材中类 <span className="text-red-500">*</span>
            </Label>
            <Select value={subCategory} onValueChange={handleSubChange} disabled={!mainCategory}>
              <SelectTrigger className="border-green-200 focus:ring-green-500">
                <SelectValue placeholder={mainCategory ? "选择资材中类" : "请先选择大类"} />
              </SelectTrigger>
              <SelectContent>
                {subCategories.map((c) => (
                  <SelectItem key={c.code} value={c.code}>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-green-600 w-8">{c.code}</span>
                      <span>{c.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {getSelectedSub() && (
              <p className="text-xs text-muted-foreground">{getSelectedSub()?.description}</p>
            )}
          </div>

          {/* 小类 */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <ChevronRight className="h-4 w-4 text-green-600" />
              资材小类 <span className="text-red-500">*</span>
            </Label>
            <Select value={minorCategory} onValueChange={setMinorCategory} disabled={!subCategory}>
              <SelectTrigger className="border-green-200 focus:ring-green-500">
                <SelectValue placeholder={subCategory ? "选择资材小类" : "请先选择中类"} />
              </SelectTrigger>
              <SelectContent>
                {minorCategories.map((c) => (
                  <SelectItem key={c.code} value={c.code}>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-green-600 w-8">{c.code}</span>
                      <span>{c.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 顺序号 */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Hash className="h-4 w-4 text-green-600" />
              顺序号
            </Label>
            <Input
              type="text"
              value={sequence}
              onChange={(e) => setSequence(e.target.value.replace(/\D/g, '').slice(0, 3).padStart(3, '0'))}
              placeholder="001"
              className="border-green-200 focus:ring-green-500 font-mono"
              maxLength={3}
            />
            <p className="text-xs text-muted-foreground">3位数字，自动补零（001-999）</p>
          </div>
        </CardContent>
      </Card>

      {/* 生成结果 */}
      <Card className="border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Sparkles className="h-5 w-5 text-green-600" />
            编码结果
          </CardTitle>
          <CardDescription>生成的资材分类编码</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* 编码展示 */}
          <div className="rounded-lg border-2 border-dashed border-green-300 bg-green-50 p-6 dark:border-green-700 dark:bg-green-950/30">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">生成的编码</p>
              {generatedCode ? (
                <code className="text-2xl font-bold text-green-700 dark:text-green-400 font-mono tracking-wider">
                  {generatedCode}
                </code>
              ) : (
                <p className="text-xl text-muted-foreground">请完成配置生成编码</p>
              )}
            </div>
          </div>

          {/* 编码解析 */}
          {generatedCode && (
            <div className="space-y-2">
              <p className="text-sm font-medium">编码解析：</p>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 p-2 rounded bg-green-50 dark:bg-green-950/30">
                  <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-400">
                    大类
                  </Badge>
                  <span>{getSelectedMain()?.name} ({mainCategory})</span>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-green-50 dark:bg-green-950/30">
                  <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-400">
                    中类
                  </Badge>
                  <span>{getSelectedSub()?.name} ({subCategory})</span>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-green-50 dark:bg-green-950/30">
                  <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-400">
                    小类
                  </Badge>
                  <span>{getSelectedMinor()?.name} ({minorCategory})</span>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-green-50 dark:bg-green-950/30">
                  <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-400">
                    序号
                  </Badge>
                  <span>{sequence}</span>
                </div>
              </div>
            </div>
          )}

          {/* 操作按钮 */}
          <div className="flex gap-2">
            <Button 
              onClick={handleCopy} 
              disabled={!generatedCode}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  已复制
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4 mr-2" />
                  复制
                </>
              )}
            </Button>
            <Button 
              onClick={handleSave}
              disabled={!generatedCode}
              variant="outline"
              className="border-green-300 hover:bg-green-50"
            >
              <Database className="h-4 w-4 mr-2" />
              保存
            </Button>
            <Button 
              variant="outline" 
              onClick={handleReset}
              className="border-green-300 hover:bg-green-50"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              重置
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ==================== 采购商编码生成器 ====================
function SupplierEncoder({ onGenerate }: { onGenerate: (record: EncodingRecord) => void }) {
  const [mainCategory, setMainCategory] = useState<string>('');
  const [subCategory, setSubCategory] = useState<string>('');
  const [minorCategory, setMinorCategory] = useState<string>('');
  const [sequence, setSequence] = useState<string>('001');
  const [copied, setCopied] = useState(false);
  const [searchMain, setSearchMain] = useState('');

  const subCategories = useMemo(() => {
    return mainCategory ? (supplierSubCategories[mainCategory] || []) : [];
  }, [mainCategory]);

  const minorCategories = useMemo(() => {
    return mainCategory && subCategory ? getSupplierMinorCategories(mainCategory, subCategory) : [];
  }, [mainCategory, subCategory]);

  const generatedCode = useMemo(() => {
    if (!mainCategory || !subCategory || !minorCategory) return '';
    return `${mainCategory}${subCategory}${minorCategory}${sequence}`;
  }, [mainCategory, subCategory, minorCategory, sequence]);

  const handleMainChange = (value: string) => {
    setMainCategory(value);
    setSubCategory('');
    setMinorCategory('');
  };

  const handleSubChange = (value: string) => {
    setSubCategory(value);
    setMinorCategory('');
  };

  const handleCopy = async () => {
    if (generatedCode) {
      await navigator.clipboard.writeText(generatedCode);
      setCopied(true);
      toast.success('编码已复制到剪贴板');
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleReset = () => {
    setMainCategory('');
    setSubCategory('');
    setMinorCategory('');
    setSequence('001');
  };

  const handleSave = () => {
    if (!generatedCode) return;
    
    const main = supplierCategories.find(c => c.code === mainCategory);
    const sub = subCategories.find(c => c.code === subCategory);
    const minor = minorCategories.find(c => c.code === minorCategory);
    
    const record: EncodingRecord = {
      code: generatedCode,
      type: 'supplier',
      mainName: main?.name || '',
      subName: sub?.name || '',
      minorName: minor?.name || '',
      sequence,
      fullPath: `${main?.name} > ${sub?.name} > ${minor?.name}`,
      createdAt: new Date().toISOString(),
    };
    
    onGenerate(record);
    toast.success('编码已保存到记录列表');
  };

  const filteredMainCategories = useMemo(() => {
    if (!searchMain) return supplierCategories;
    return supplierCategories.filter(c => 
      c.name.toLowerCase().includes(searchMain.toLowerCase()) ||
      c.code.toLowerCase().includes(searchMain.toLowerCase())
    );
  }, [searchMain]);

  const getSelectedMain = () => supplierCategories.find(c => c.code === mainCategory);
  const getSelectedSub = () => subCategories.find(c => c.code === subCategory);
  const getSelectedMinor = () => minorCategories.find(c => c.code === minorCategory);

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {/* 编码规则说明 */}
      <Card className="lg:col-span-2 border-green-200 bg-gradient-to-r from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-green-700 dark:text-green-400">
            <Info className="h-5 w-5" />
            采购商/供应商编码规则
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="border-green-300 text-green-700 dark:border-green-700 dark:text-green-400">
                结构
              </Badge>
              <code className="rounded bg-green-100 px-2 py-1 text-sm dark:bg-green-900/30">
                {encodingRules.supplier.structure}
              </code>
            </div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="border-green-300 text-green-700 dark:border-green-700 dark:text-green-400">
                示例
              </Badge>
              <code className="rounded bg-green-100 px-2 py-1 font-mono text-sm text-green-700 dark:bg-green-900/30 dark:text-green-400">
                {encodingRules.supplier.example}
              </code>
            </div>
          </div>
          <p className="mt-2 text-sm text-green-600 dark:text-green-400/80">
            {encodingRules.supplier.exampleDetail} → {encodingRules.supplier.example}
          </p>
        </CardContent>
      </Card>

      {/* 选择区域 */}
      <Card className="border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Building2 className="h-5 w-5 text-green-600" />
            供应商分类
          </CardTitle>
          <CardDescription>选择供应商分类层级</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* 大类 */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Layers className="h-4 w-4 text-green-600" />
              供应商大类 <span className="text-red-500">*</span>
            </Label>
            <div className="relative mb-2">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="搜索供应商类型..."
                value={searchMain}
                onChange={(e) => setSearchMain(e.target.value)}
                className="pl-9 border-green-200 focus:ring-green-500"
              />
            </div>
            <Select value={mainCategory} onValueChange={handleMainChange}>
              <SelectTrigger className="border-green-200 focus:ring-green-500">
                <SelectValue placeholder="选择供应商大类" />
              </SelectTrigger>
              <SelectContent>
                <ScrollArea className="h-48">
                  {filteredMainCategories.map((c) => (
                    <SelectItem key={c.code} value={c.code}>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-green-600 w-16">{c.code}</span>
                        <span>{c.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </ScrollArea>
              </SelectContent>
            </Select>
            {getSelectedMain() && (
              <p className="text-xs text-muted-foreground">{getSelectedMain()?.english} - {getSelectedMain()?.description}</p>
            )}
          </div>

          {/* 中类 */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <ChevronRight className="h-4 w-4 text-green-600" />
              供应商中类 <span className="text-red-500">*</span>
            </Label>
            <Select value={subCategory} onValueChange={handleSubChange} disabled={!mainCategory}>
              <SelectTrigger className="border-green-200 focus:ring-green-500">
                <SelectValue placeholder={mainCategory ? "选择供应商中类" : "请先选择大类"} />
              </SelectTrigger>
              <SelectContent>
                {subCategories.map((c) => (
                  <SelectItem key={c.code} value={c.code}>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-green-600 w-8">{c.code}</span>
                      <span>{c.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 小类 */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <ChevronRight className="h-4 w-4 text-green-600" />
              供应商小类 <span className="text-red-500">*</span>
            </Label>
            <Select value={minorCategory} onValueChange={setMinorCategory} disabled={!subCategory}>
              <SelectTrigger className="border-green-200 focus:ring-green-500">
                <SelectValue placeholder={subCategory ? "选择供应商小类" : "请先选择中类"} />
              </SelectTrigger>
              <SelectContent>
                {minorCategories.map((c) => (
                  <SelectItem key={c.code} value={c.code}>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-green-600 w-8">{c.code}</span>
                      <span>{c.name}</span>
                    </div>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* 顺序号 */}
          <div className="space-y-2">
            <Label className="flex items-center gap-2">
              <Hash className="h-4 w-4 text-green-600" />
              顺序号
            </Label>
            <Input
              type="text"
              value={sequence}
              onChange={(e) => setSequence(e.target.value.replace(/\D/g, '').slice(0, 3).padStart(3, '0'))}
              placeholder="001"
              className="border-green-200 focus:ring-green-500 font-mono"
              maxLength={3}
            />
            <p className="text-xs text-muted-foreground">3位数字，自动补零（001-999）</p>
          </div>
        </CardContent>
      </Card>

      {/* 生成结果 */}
      <Card className="border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Sparkles className="h-5 w-5 text-green-600" />
            编码结果
          </CardTitle>
          <CardDescription>生成的供应商编码</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* 编码展示 */}
          <div className="rounded-lg border-2 border-dashed border-green-300 bg-green-50 p-6 dark:border-green-700 dark:bg-green-950/30">
            <div className="text-center">
              <p className="text-sm text-muted-foreground mb-2">生成的编码</p>
              {generatedCode ? (
                <code className="text-xl font-bold text-green-700 dark:text-green-400 font-mono tracking-wider">
                  {generatedCode}
                </code>
              ) : (
                <p className="text-xl text-muted-foreground">请完成配置生成编码</p>
              )}
            </div>
          </div>

          {/* 编码解析 */}
          {generatedCode && (
            <div className="space-y-2">
              <p className="text-sm font-medium">编码解析：</p>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2 p-2 rounded bg-green-50 dark:bg-green-950/30">
                  <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-400">
                    大类
                  </Badge>
                  <span>{getSelectedMain()?.name} ({mainCategory})</span>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-green-50 dark:bg-green-950/30">
                  <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-400">
                    中类
                  </Badge>
                  <span>{getSelectedSub()?.name} ({subCategory})</span>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-green-50 dark:bg-green-950/30">
                  <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-400">
                    小类
                  </Badge>
                  <span>{getSelectedMinor()?.name} ({minorCategory})</span>
                </div>
                <div className="flex items-center gap-2 p-2 rounded bg-green-50 dark:bg-green-950/30">
                  <Badge variant="secondary" className="bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-400">
                    序号
                  </Badge>
                  <span>{sequence}</span>
                </div>
              </div>
            </div>
          )}

          {/* 操作按钮 */}
          <div className="flex gap-2">
            <Button 
              onClick={handleCopy} 
              disabled={!generatedCode}
              className="flex-1 bg-green-600 hover:bg-green-700"
            >
              {copied ? (
                <>
                  <Check className="h-4 w-4 mr-2" />
                  已复制
                </>
              ) : (
                <>
                  <Copy className="h-4 w-4 mr-2" />
                  复制
                </>
              )}
            </Button>
            <Button 
              onClick={handleSave}
              disabled={!generatedCode}
              variant="outline"
              className="border-green-300 hover:bg-green-50"
            >
              <Database className="h-4 w-4 mr-2" />
              保存
            </Button>
            <Button 
              variant="outline" 
              onClick={handleReset}
              className="border-green-300 hover:bg-green-50"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              重置
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// ==================== 快速查询组件 ====================
function QuickQuery() {
  const [queryCode, setQueryCode] = useState('');
  const [result, setResult] = useState<{
    type: 'material' | 'supplier' | null;
    parsed: Array<{ label: string; value: string }>;
  } | null>(null);

  const handleQuery = () => {
    if (!queryCode) return;

    // 尝试解析为供应商编码
    if (queryCode.startsWith('SU_')) {
      const parsed = parseSupplierCode(queryCode);
      if (parsed && parsed.isValid) {
        setResult({
          type: 'supplier',
          parsed: [
            { label: '编码类型', value: '供应商编码' },
            { label: '大类', value: `${parsed.main?.name} (${parsed.mainCode})` },
            { label: '中类', value: `${parsed.sub?.name} (${parsed.subCode})` },
            { label: '小类', value: `${parsed.minor?.name} (${parsed.minorCode})` },
            { label: '顺序号', value: parsed.seq },
          ]
        });
        return;
      }
    } else {
      // 尝试解析为资材编码
      const parsed = parseMaterialCode(queryCode);
      if (parsed && parsed.isValid) {
        setResult({
          type: 'material',
          parsed: [
            { label: '编码类型', value: '资材编码' },
            { label: '大类', value: `${parsed.main?.name} (${parsed.mainCode})` },
            { label: '中类', value: `${parsed.sub?.name} (${parsed.subCode})` },
            { label: '小类', value: `${parsed.minor?.name} (${parsed.minorCode})` },
            { label: '顺序号', value: parsed.seq },
          ]
        });
        return;
      }
    }

    setResult(null);
    toast.error('无效的编码格式');
  };

  return (
    <Card className="border-green-200">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Search className="h-5 w-5 text-green-600" />
          编码查询
        </CardTitle>
        <CardDescription>输入编码快速解析其含义</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex gap-2">
          <Input
            placeholder="输入编码，如：SP0101001 或 SU_SP01001"
            value={queryCode}
            onChange={(e) => setQueryCode(e.target.value.toUpperCase())}
            className="border-green-200 focus:ring-green-500 font-mono"
          />
          <Button onClick={handleQuery} className="bg-green-600 hover:bg-green-700">
            查询
          </Button>
        </div>

        {result && (
          <div className="rounded-lg border border-green-200 bg-green-50 p-4 dark:border-green-700 dark:bg-green-950/30">
            <div className="flex items-center gap-2 mb-3">
              <Badge className={result.type === 'supplier' ? 'bg-blue-500' : 'bg-purple-500'}>
                {result.type === 'supplier' ? '供应商编码' : '资材编码'}
              </Badge>
            </div>
            <div className="space-y-2">
              {result.parsed.map((item, index) => (
                <div key={index} className="flex items-center gap-2 text-sm">
                  <span className="font-medium text-green-700 dark:text-green-400 min-w-20">{item.label}:</span>
                  <span className="text-muted-foreground">{item.value}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}


// ==================== 编码记录列表 ====================
function EncodingRecords({ 
  records, 
  onClear 
}: { 
  records: EncodingRecord[];
  onClear: () => void;
}) {
  const exportToCSV = useCallback(() => {
    if (records.length === 0) {
      toast.error('没有可导出的记录');
      return;
    }

    const headers = ['编码', '类型', '大类', '中类', '小类', '序号', '完整路径', '创建时间'];
    const rows = records.map(r => [
      r.code,
      r.type === 'material' ? '资材' : '供应商',
      r.mainName,
      r.subName,
      r.minorName,
      r.sequence,
      r.fullPath,
      new Date(r.createdAt).toLocaleString('zh-CN'),
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(','))
    ].join('\n');

    // 添加BOM以支持中文
    const BOM = '\uFEFF';
    const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `弘智耘编码记录_${new Date().toISOString().slice(0, 10)}.csv`;
    link.click();
    URL.revokeObjectURL(url);
    
    toast.success('CSV文件已下载');
  }, [records]);

  const exportToJSON = useCallback(() => {
    if (records.length === 0) {
      toast.error('没有可导出的记录');
      return;
    }

    const jsonContent = JSON.stringify(records, null, 2);
    const blob = new Blob([jsonContent], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `弘智耘编码记录_${new Date().toISOString().slice(0, 10)}.json`;
    link.click();
    URL.revokeObjectURL(url);
    
    toast.success('JSON文件已下载');
  }, [records]);

  const exportToTXT = useCallback(() => {
    if (records.length === 0) {
      toast.error('没有可导出的记录');
      return;
    }

    const lines = records.map(r => 
      `${r.code}\t${r.type === 'material' ? '资材' : '供应商'}\t${r.fullPath}`
    );
    const content = ['编码\t类型\t完整路径', ...lines].join('\n');
    const blob = new Blob([content], { type: 'text/plain;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `弘智耘编码记录_${new Date().toISOString().slice(0, 10)}.txt`;
    link.click();
    URL.revokeObjectURL(url);
    
    toast.success('TXT文件已下载');
  }, [records]);

  const copyAllCodes = useCallback(async () => {
    if (records.length === 0) {
      toast.error('没有可复制的记录');
      return;
    }
    const codes = records.map(r => r.code).join('\n');
    await navigator.clipboard.writeText(codes);
    toast.success(`已复制 ${records.length} 个编码到剪贴板`);
  }, [records]);

  return (
    <Card className="border-green-200">
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Table className="h-5 w-5 text-green-600" />
              编码记录
            </CardTitle>
            <CardDescription>
              已生成 {records.length} 条编码记录
            </CardDescription>
          </div>
          <div className="flex gap-2">
            <Button 
              variant="outline" 
              size="sm"
              onClick={copyAllCodes}
              disabled={records.length === 0}
              className="border-green-300"
            >
              <Copy className="h-4 w-4 mr-1" />
              复制全部
            </Button>
            <Button 
              variant="outline" 
              size="sm"
              onClick={onClear}
              disabled={records.length === 0}
              className="border-red-300 text-red-600 hover:bg-red-50"
            >
              清空
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {records.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            <Database className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>暂无编码记录</p>
            <p className="text-sm">生成编码后点击"保存"按钮添加记录</p>
          </div>
        ) : (
          <>
            <ScrollArea className="h-64 mb-4">
              <div className="space-y-2">
                {records.map((record, index) => (
                  <div 
                    key={index}
                    className="flex items-center justify-between p-3 rounded-lg bg-green-50 dark:bg-green-950/30 border border-green-200"
                  >
                    <div className="flex items-center gap-3">
                      <Badge 
                        variant="outline"
                        className={record.type === 'material' ? 'border-purple-300 text-purple-700' : 'border-blue-300 text-blue-700'}
                      >
                        {record.type === 'material' ? '资材' : '供应商'}
                      </Badge>
                      <code className="font-mono font-bold text-green-700 dark:text-green-400">
                        {record.code}
                      </code>
                      <span className="text-sm text-muted-foreground hidden md:inline">
                        {record.fullPath}
                      </span>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={async () => {
                        await navigator.clipboard.writeText(record.code);
                        toast.success('已复制');
                      }}
                    >
                      <Copy className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </ScrollArea>

            <Separator className="my-4" />

            <div className="space-y-2">
              <p className="text-sm font-medium text-green-700 dark:text-green-400">导出到本地文件：</p>
              <div className="flex flex-wrap gap-2">
                <Button 
                  onClick={exportToCSV}
                  variant="outline"
                  className="border-green-300 hover:bg-green-50"
                >
                  <FileSpreadsheet className="h-4 w-4 mr-2" />
                  导出 CSV
                </Button>
                <Button 
                  onClick={exportToJSON}
                  variant="outline"
                  className="border-green-300 hover:bg-green-50"
                >
                  <FileText className="h-4 w-4 mr-2" />
                  导出 JSON
                </Button>
                <Button 
                  onClick={exportToTXT}
                  variant="outline"
                  className="border-green-300 hover:bg-green-50"
                >
                  <FileText className="h-4 w-4 mr-2" />
                  导出 TXT
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">
                CSV文件可用Excel打开，支持中文显示
              </p>
            </div>
          </>
        )}
      </CardContent>
    </Card>
  );
}

// ==================== 主页面 ====================
export default function HomePage() {
  const [records, setRecords] = useState<EncodingRecord[]>([]);

  const handleGenerate = useCallback((record: EncodingRecord) => {
    setRecords(prev => [record, ...prev]);
  }, []);

  const handleClear = useCallback(() => {
    setRecords([]);
    toast.success('记录已清空');
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-white dark:from-green-950/20 dark:to-background">
      {/* 头部 */}
      <header className="border-b border-green-200 bg-white/80 backdrop-blur-sm dark:bg-background/80 dark:border-green-800 sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-green-500 to-emerald-600 shadow-lg shadow-green-500/25">
                <Hash className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl font-bold text-green-700 dark:text-green-400">
                  弘智耘编码系统
                </h1>
                <p className="text-xs text-muted-foreground">
                  采购商与资材分类智能编码平台
                </p>
              </div>
            </div>
            <Badge variant="outline" className="border-green-300 text-green-700 dark:border-green-600 dark:text-green-400">
              v2.0
            </Badge>
          </div>
        </div>
      </header>

      {/* 主内容 */}
      <main className="container mx-auto px-4 py-6">
        {/* 快速查询 */}
        <div className="mb-6">
          <QuickQuery />
        </div>

        <Separator className="my-4 bg-green-200 dark:bg-green-800" />

        {/* 编码生成器 */}
        <Tabs defaultValue="material" className="space-y-4">
          <TabsList className="grid w-full max-w-md grid-cols-2 bg-green-100 dark:bg-green-900/30">
            <TabsTrigger 
              value="material" 
              className="data-[state=active]:bg-white data-[state=active]:text-green-700 dark:data-[state=active]:bg-green-900 dark:data-[state=active]:text-green-400"
            >
              <Package className="h-4 w-4 mr-2" />
              资材编码
            </TabsTrigger>
            <TabsTrigger 
              value="supplier"
              className="data-[state=active]:bg-white data-[state=active]:text-green-700 dark:data-[state=active]:bg-green-900 dark:data-[state=active]:text-green-400"
            >
              <Building2 className="h-4 w-4 mr-2" />
              供应商编码
            </TabsTrigger>
          </TabsList>

          <TabsContent value="material">
            <MaterialEncoder onGenerate={handleGenerate} />
          </TabsContent>

          <TabsContent value="supplier">
            <SupplierEncoder onGenerate={handleGenerate} />
          </TabsContent>
        </Tabs>

        <Separator className="my-4 bg-green-200 dark:bg-green-800" />

        {/* 编码记录 */}
        <EncodingRecords records={records} onClear={handleClear} />

        {/* 底部统计 */}
        <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-3">
          <Card className="border-green-200 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30">
            <CardContent className="pt-4 pb-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{materialCategories.length}</p>
                <p className="text-xs text-muted-foreground">资材大类</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-green-200 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30">
            <CardContent className="pt-4 pb-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{supplierCategories.length}</p>
                <p className="text-xs text-muted-foreground">供应商大类</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-green-200 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30">
            <CardContent className="pt-4 pb-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">
                  {Object.keys(materialSubCategories).reduce((sum, key) => sum + materialSubCategories[key].length, 0)}
                </p>
                <p className="text-xs text-muted-foreground">资材中类</p>
              </div>
            </CardContent>
          </Card>
          <Card className="border-green-200 bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-950/30 dark:to-emerald-950/30">
            <CardContent className="pt-4 pb-4">
              <div className="text-center">
                <p className="text-2xl font-bold text-green-600">{records.length}</p>
                <p className="text-xs text-muted-foreground">已生成编码</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* 页脚 */}
      <footer className="border-t border-green-200 bg-white/80 dark:bg-background/80 dark:border-green-800 mt-8">
        <div className="container mx-auto px-4 py-4">
          <div className="text-center text-xs text-muted-foreground">
            <p>弘智耘采购商和资材分类编码系统 © 2026</p>
            <p className="mt-1">智能编码 · 规范管理 · 高效协作</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
