import { NextRequest, NextResponse } from 'next/server';
import { FetchClient, Config, HeaderUtils } from 'coze-coding-dev-sdk';

export async function GET(request: NextRequest) {
  try {
    const url = 'https://coze-coding-project.tos.coze.site/create_attachment/2026-03-12/2684350380907976_e8329df25c078bebd9615b1d8c7d64a7_%E5%BC%98%E6%99%BA%E8%80%95%E9%87%87%E8%B4%AD%E5%95%86%E5%92%8C%E8%B5%84%E6%9D%90%E5%88%86%E7%B1%BB%E7%BC%96%E7%A0%81-%E9%99%86%E5%90%AF%E9%97%AF-202602.xlsx?sign=4895373472-a6c137cbba-0-54687d80e7edb5ab32b13bdbccdd9a818a338897fc70507439006d02b64292ca';
    
    const customHeaders = HeaderUtils.extractForwardHeaders(request.headers);
    const config = new Config();
    const client = new FetchClient(config, customHeaders);

    const response = await client.fetch(url);

    if (response.status_code !== 0) {
      return NextResponse.json({ 
        error: response.status_message || 'Failed to fetch file',
        status_code: response.status_code
      }, { status: 500 });
    }

    // 提取文本内容
    const textContent = response.content
      .filter(item => item.type === 'text')
      .map(item => item.text)
      .join('\n');

    return NextResponse.json({
      title: response.title,
      filetype: response.filetype,
      content: textContent,
      success: true
    });
  } catch (error) {
    console.error('Error fetching Excel:', error);
    return NextResponse.json({ 
      error: 'Failed to fetch and parse Excel file',
      details: error instanceof Error ? error.message : 'Unknown error'
    }, { status: 500 });
  }
}
