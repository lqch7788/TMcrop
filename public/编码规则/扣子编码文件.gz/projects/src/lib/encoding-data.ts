// 弘智耘采购商和资材分类编码数据结构
// 基于Excel文件: 弘智耘采购商和资材分类编码-陆启闯-202602.xlsx

// ==================== 资材分类编码 ====================

// 资材大类
export const materialCategories = [
  { code: 'SP', name: '种质资源', english: 'Seed & Planting Inputs', description: '种子、种苗等种质资源' },
  { code: 'FE', name: '肥料与土壤改良剂', english: 'Fertilizer & Soil', description: '有机肥、化肥、土壤调理剂等' },
  { code: 'PP', name: '农药与植保产品', english: 'Pesticide & Plant Protection', description: '杀虫剂、杀菌剂、除草剂等' },
  { code: 'EQ', name: '设施与装备', english: 'Facilities and Equipment', description: '农业机械、设备等' },
  { code: 'FA', name: '设施农业', english: 'Facility Agriculture', description: '大棚/温室专用资材' },
  { code: 'IR', name: '灌溉系统', english: 'Irrigation System', description: '灌溉与水肥一体化设备' },
  { code: 'OP', name: '作业支持', english: 'Operations Support', description: '劳保用品、劳动工具等' },
  { code: 'PH', name: '采后处理与流通', english: 'Post-harvest Handling', description: '采收容器、包装、冷链等' },
  { code: 'IT', name: '数字化与管理', english: 'Information Technology', description: '检测设备、软件服务等' },
  { code: 'EC', name: '能源与通用耗材', english: 'Energy and Consumables', description: '能源、通用耗材等' },
  { code: 'OT', name: '其他', english: 'Others', description: '其他未分类资材' },
];

// 资材中类（按大类分组）
export const materialSubCategories: Record<string, Array<{ code: string; name: string; description?: string }>> = {
  'SP': [ // 种质资源
    { code: '01', name: '粮食作物种子', description: '水稻、小麦、玉米等' },
    { code: '02', name: '蔬菜种子/种苗', description: '各类蔬菜种子和种苗' },
    { code: '03', name: '水果苗木', description: '果树、浆果等苗木' },
    { code: '04', name: '花卉与观赏植物', description: '花卉种子、苗木' },
    { code: '05', name: '食用菌菌种', description: '食用菌/药用菌菌种' },
    { code: '99', name: '其他种质资源', description: '其他未分类种质资源' },
  ],
  'FE': [ // 肥料与土壤改良剂
    { code: '01', name: '有机肥', description: '商品有机肥、堆肥等' },
    { code: '02', name: '化学肥料', description: '复合肥、尿素、水溶肥等' },
    { code: '03', name: '微生物菌剂', description: '枯草芽孢杆菌、固氮菌等' },
    { code: '04', name: '土壤调理剂', description: '石灰、腐殖酸等' },
    { code: '05', name: '育苗基质', description: '椰糠、泥炭、珍珠岩等' },
    { code: '99', name: '其他肥料类', description: '其他未分类肥料' },
  ],
  'PP': [ // 农药与植保产品
    { code: '01', name: '杀虫剂', description: '各类杀虫药剂' },
    { code: '02', name: '杀菌剂', description: '各类杀菌药剂' },
    { code: '03', name: '除草剂', description: '各类除草药剂' },
    { code: '04', name: '杀螨剂', description: '各类杀螨药剂' },
    { code: '05', name: '植物生长调节剂', description: '各类调节剂' },
    { code: '06', name: '杀鼠剂', description: '各类杀鼠药剂' },
    { code: '07', name: '杀软体动物剂', description: '杀螺、杀蜗牛等' },
    { code: '08', name: '绿色防控产品', description: '黄板、诱捕器、性诱剂等' },
    { code: '09', name: '生物农药', description: '生物源农药' },
    { code: '99', name: '其他植保产品', description: '其他未分类植保产品' },
  ],
  'EQ': [ // 设施与装备
    { code: '01', name: '耕作机械', description: '拖拉机、微耕机' },
    { code: '02', name: '播种/移栽设备', description: '播种机、移栽机' },
    { code: '03', name: '植保机械', description: '喷雾机、无人机' },
    { code: '04', name: '收获机械', description: '收割机、采摘机器人' },
    { code: '05', name: '初加工设备', description: '分选、加工设备' },
    { code: '99', name: '其他农机设备', description: '其他未分类农机' },
  ],
  'FA': [ // 设施农业
    { code: '01', name: '骨架结构材料', description: '镀锌管、铝合金等' },
    { code: '02', name: '覆盖材料', description: 'PO膜、EVA膜、防虫网、遮阳网' },
    { code: '03', name: '通风降温设备', description: '风机、湿帘' },
    { code: '04', name: '加温设备', description: '热风炉、地暖' },
    { code: '05', name: '补光系统', description: 'LED植物灯' },
    { code: '06', name: '智能环控系统', description: '传感器、控制器' },
    { code: '99', name: '其他设施农业资材', description: '其他未分类设施资材' },
  ],
  'IR': [ // 灌溉系统
    { code: '01', name: '水源与泵站', description: '水泵与水源设备' },
    { code: '02', name: '输水管网', description: 'PVC/PE管材管件' },
    { code: '03', name: '过滤系统', description: '叠片、砂石过滤器' },
    { code: '04', name: '施肥装置', description: '注肥泵、文丘里' },
    { code: '05', name: '灌溉终端', description: '滴头、微喷头、滴灌带' },
    { code: '99', name: '其他灌溉设备', description: '其他未分类灌溉设备' },
  ],
  'OP': [ // 作业支持
    { code: '01', name: '手部防护', description: '手套等' },
    { code: '02', name: '足部防护', description: '胶靴、雨鞋' },
    { code: '03', name: '呼吸/眼部防护', description: '口罩、护目镜' },
    { code: '04', name: '身体防护', description: '工作服、反光背心' },
    { code: '05', name: '防晒防暑用品', description: '草帽、冰袖' },
    { code: '06', name: '日常劳动工具', description: '锄头、铁锹、修枝剪' },
    { code: '07', name: '小型电动工具', description: '手持打药机、电锯' },
    { code: '08', name: '清洁工具', description: '扫帚、水桶、抹布' },
    { code: '09', name: '标识记录用品', description: '田间标牌、记录本' },
    { code: '99', name: '其他作业支持用品', description: '其他未分类作业支持' },
  ],
  'PH': [ // 采后处理与流通
    { code: '01', name: '采收容器', description: '塑料周转箱、采摘篮' },
    { code: '02', name: '包装材料', description: '纸箱、网套、胶带' },
    { code: '03', name: '冷链设备', description: '预冷库、冷藏车、保温箱' },
    { code: '04', name: '装卸仓储设备', description: '手推车、托盘' },
    { code: '99', name: '其他采后处理', description: '其他未分类采后处理' },
  ],
  'IT': [ // 数字化与管理
    { code: '01', name: '监测设备', description: '气象站、虫情测报灯、监控' },
    { code: '02', name: '控制设备', description: '传感器、控制器、HMI' },
    { code: '03', name: '软件与服务', description: 'ERP模块、数据分析服务' },
    { code: '04', name: '检测服务', description: '土壤检测、水质检测' },
    { code: '05', name: '手持检测设备', description: '农残快检设备' },
    { code: '99', name: '其他技术服务', description: '其他未分类技术服务' },
  ],
  'EC': [ // 能源与通用耗材
    { code: '01', name: '能源类', description: '柴油、汽油、电力' },
    { code: '02', name: '通用耗材', description: '电线、扎带、螺丝等' },
    { code: '99', name: '其他耗材', description: '其他未分类耗材' },
  ],
  'OT': [ // 其他
    { code: '99', name: '未分类资材', description: '其他未分类资材' },
  ],
};

// 资材小类（按大类+中类分组）
export const materialMinorCategories: Record<string, Array<{ code: string; name: string; description?: string }>> = {
  // SP - 种质资源
  'SP-01': [ // 粮食作物种子
    { code: '01', name: '水稻种子' },
    { code: '02', name: '小麦种子' },
    { code: '03', name: '玉米种子' },
    { code: '04', name: '大豆种子' },
    { code: '05', name: '薯类种薯' },
    { code: '99', name: '其他粮食作物种子' },
  ],
  'SP-02': [ // 蔬菜种子/种苗
    { code: '01', name: '叶菜类种子' },
    { code: '02', name: '茄果类种子' },
    { code: '03', name: '瓜类种子' },
    { code: '04', name: '根茎类种子' },
    { code: '05', name: '蔬菜种苗' },
    { code: '99', name: '其他蔬菜种子' },
  ],
  'SP-03': [ // 水果苗木
    { code: '01', name: '柑橘苗木' },
    { code: '02', name: '苹果苗木' },
    { code: '03', name: '葡萄苗木' },
    { code: '04', name: '浆果苗木' },
    { code: '05', name: '热带水果苗木' },
    { code: '99', name: '其他水果苗木' },
  ],
  'SP-04': [ // 花卉与观赏植物
    { code: '01', name: '观赏花卉种子' },
    { code: '02', name: '绿化苗木' },
    { code: '03', name: '盆栽植物' },
    { code: '99', name: '其他花卉植物' },
  ],
  'SP-05': [ // 食用菌菌种
    { code: '01', name: '香菇菌种' },
    { code: '02', name: '平菇菌种' },
    { code: '03', name: '木耳菌种' },
    { code: '04', name: '金针菇菌种' },
    { code: '99', name: '其他食用菌菌种' },
  ],

  // FE - 肥料与土壤改良剂
  'FE-01': [ // 有机肥
    { code: '01', name: '农家肥（堆肥）' },
    { code: '02', name: '商品有机肥' },
    { code: '03', name: '生物有机肥' },
    { code: '04', name: '秸秆堆肥' },
    { code: '05', name: '绿肥作物' },
    { code: '99', name: '其他有机肥' },
  ],
  'FE-02': [ // 化学肥料
    { code: '01', name: '氮肥' },
    { code: '02', name: '磷肥' },
    { code: '03', name: '钾肥' },
    { code: '04', name: '复合肥' },
    { code: '05', name: '微量元素肥' },
    { code: '06', name: '水溶肥' },
    { code: '99', name: '其他化肥' },
  ],
  'FE-03': [ // 微生物菌剂
    { code: '01', name: '根瘤菌剂' },
    { code: '02', name: '固氮菌剂' },
    { code: '03', name: '解磷菌剂' },
    { code: '04', name: '解钾菌剂' },
    { code: '05', name: '光合细菌剂' },
    { code: '06', name: '腐熟剂' },
    { code: '07', name: '促生菌剂' },
    { code: '08', name: '菌根菌剂' },
    { code: '09', name: '修复菌剂' },
    { code: '10', name: '复合微生物菌剂' },
    { code: '99', name: '其他微生物菌剂' },
  ],
  'FE-04': [ // 土壤调理剂
    { code: '01', name: '石灰类' },
    { code: '02', name: '腐殖酸类' },
    { code: '03', name: '石膏类' },
    { code: '99', name: '其他土壤调理剂' },
  ],
  'FE-05': [ // 育苗基质
    { code: '01', name: '椰糠' },
    { code: '02', name: '泥炭' },
    { code: '03', name: '珍珠岩' },
    { code: '04', name: '蛭石' },
    { code: '05', name: '复合基质' },
    { code: '99', name: '其他育苗基质' },
  ],

  // PP - 农药与植保产品
  'PP-01': [ // 杀虫剂
    { code: '01', name: '有机磷类杀虫剂' },
    { code: '02', name: '氨基甲酸酯类杀虫剂' },
    { code: '03', name: '拟除虫菊酯类杀虫剂' },
    { code: '04', name: '苯甲酰脲类杀虫剂' },
    { code: '05', name: '微生物源杀虫剂' },
    { code: '06', name: '新烟碱类杀虫剂' },
    { code: '07', name: '其他类杀虫剂' },
  ],
  'PP-02': [ // 杀菌剂
    { code: '01', name: '保护性杀菌剂' },
    { code: '02', name: '内吸性杀菌剂' },
    { code: '03', name: '细菌性病害防治药剂' },
    { code: '04', name: '生物源杀菌剂' },
    { code: '05', name: '杀线虫剂' },
  ],
  'PP-03': [ // 除草剂
    { code: '01', name: '选择性除草剂' },
    { code: '02', name: '灭生性除草剂' },
  ],
  'PP-04': [ // 杀螨剂
    { code: '01', name: '哒螨灵类' },
    { code: '02', name: '螺螨酯类' },
    { code: '03', name: '其他杀螨剂' },
  ],
  'PP-05': [ // 植物生长调节剂
    { code: '01', name: '生长素类调节剂' },
    { code: '02', name: '赤霉素类调节剂' },
    { code: '03', name: '乙烯释放剂' },
    { code: '04', name: '脱落酸类调节剂' },
    { code: '05', name: '生长延缓剂和抑制剂' },
    { code: '06', name: '复合型植物生长调节剂' },
  ],
  'PP-06': [ // 杀鼠剂
    { code: '01', name: '抗凝血杀鼠剂' },
    { code: '02', name: '急性杀鼠剂' },
  ],
  'PP-07': [ // 杀软体动物剂
    { code: '01', name: '杀螺剂' },
    { code: '02', name: '其他杀软体动物剂' },
  ],
  'PP-08': [ // 绿色防控产品
    { code: '01', name: '黄板/蓝板' },
    { code: '02', name: '诱捕器' },
    { code: '03', name: '性诱剂' },
    { code: '04', name: '杀虫灯' },
    { code: '99', name: '其他绿色防控产品' },
  ],
  'PP-09': [ // 生物农药
    { code: '01', name: '苏云金杆菌（Bt）' },
    { code: '02', name: '阿维菌素' },
    { code: '03', name: '白僵菌/绿僵菌' },
    { code: '04', name: '其他生物农药' },
  ],

  // EQ - 设施与装备
  'EQ-01': [ // 耕作机械
    { code: '01', name: '拖拉机' },
    { code: '02', name: '微耕机' },
    { code: '03', name: '旋耕机' },
    { code: '04', name: '深松机' },
    { code: '99', name: '其他耕作机械' },
  ],
  'EQ-02': [ // 播种/移栽设备
    { code: '01', name: '播种机' },
    { code: '02', name: '移栽机' },
    { code: '03', name: '育苗设备' },
    { code: '99', name: '其他播种移栽设备' },
  ],
  'EQ-03': [ // 植保机械
    { code: '01', name: '喷雾机' },
    { code: '02', name: '无人机' },
    { code: '03', name: '喷粉机' },
    { code: '99', name: '其他植保机械' },
  ],
  'EQ-04': [ // 收获机械
    { code: '01', name: '收割机' },
    { code: '02', name: '采摘机器人' },
    { code: '03', name: '脱粒机' },
    { code: '99', name: '其他收获机械' },
  ],
  'EQ-05': [ // 初加工设备
    { code: '01', name: '分选设备' },
    { code: '02', name: '烘干设备' },
    { code: '03', name: '包装设备' },
    { code: '99', name: '其他初加工设备' },
  ],

  // FA - 设施农业
  'FA-01': [ // 骨架结构材料
    { code: '01', name: '镀锌管' },
    { code: '02', name: '铝合金骨架' },
    { code: '03', name: '连接件' },
    { code: '99', name: '其他骨架材料' },
  ],
  'FA-02': [ // 覆盖材料
    { code: '01', name: 'PO膜' },
    { code: '02', name: 'EVA膜' },
    { code: '03', name: '防虫网' },
    { code: '04', name: '遮阳网' },
    { code: '05', name: '保温被' },
    { code: '99', name: '其他覆盖材料' },
  ],
  'FA-03': [ // 通风降温设备
    { code: '01', name: '风机' },
    { code: '02', name: '湿帘' },
    { code: '03', name: '卷膜器' },
    { code: '99', name: '其他通风设备' },
  ],
  'FA-04': [ // 加温设备
    { code: '01', name: '热风炉' },
    { code: '02', name: '地暖' },
    { code: '03', name: '热风机' },
    { code: '99', name: '其他加温设备' },
  ],
  'FA-05': [ // 补光系统
    { code: '01', name: 'LED植物灯' },
    { code: '02', name: '高压钠灯' },
    { code: '03', name: '补光控制器' },
    { code: '99', name: '其他补光设备' },
  ],
  'FA-06': [ // 智能环控系统
    { code: '01', name: '传感器' },
    { code: '02', name: '控制器' },
    { code: '03', name: '执行器' },
    { code: '04', name: '监控系统' },
    { code: '99', name: '其他环控设备' },
  ],

  // IR - 灌溉系统
  'IR-01': [ // 水源与泵站
    { code: '01', name: '水泵' },
    { code: '02', name: '水源设备' },
    { code: '03', name: '水箱/水池' },
    { code: '99', name: '其他水源设备' },
  ],
  'IR-02': [ // 输水管网
    { code: '01', name: 'PVC管材' },
    { code: '02', name: 'PE管材' },
    { code: '03', name: '管件' },
    { code: '99', name: '其他管材管件' },
  ],
  'IR-03': [ // 过滤系统
    { code: '01', name: '叠片过滤器' },
    { code: '02', name: '砂石过滤器' },
    { code: '03', name: '网式过滤器' },
    { code: '99', name: '其他过滤器' },
  ],
  'IR-04': [ // 施肥装置
    { code: '01', name: '注肥泵' },
    { code: '02', name: '文丘里' },
    { code: '03', name: '施肥罐' },
    { code: '04', name: '水肥一体机' },
    { code: '99', name: '其他施肥装置' },
  ],
  'IR-05': [ // 灌溉终端
    { code: '01', name: '滴头' },
    { code: '02', name: '微喷头' },
    { code: '03', name: '滴灌带' },
    { code: '04', name: '喷带' },
    { code: '99', name: '其他灌溉终端' },
  ],

  // OP - 作业支持
  'OP-01': [ // 手部防护
    { code: '01', name: '棉纱手套' },
    { code: '02', name: '橡胶手套' },
    { code: '03', name: '防护手套' },
    { code: '99', name: '其他手套' },
  ],
  'OP-02': [ // 足部防护
    { code: '01', name: '胶靴' },
    { code: '02', name: '雨鞋' },
    { code: '03', name: '防护鞋' },
    { code: '99', name: '其他防护鞋' },
  ],
  'OP-03': [ // 呼吸/眼部防护
    { code: '01', name: '口罩' },
    { code: '02', name: '护目镜' },
    { code: '03', name: '防毒面具' },
    { code: '99', name: '其他呼吸眼部防护' },
  ],
  'OP-04': [ // 身体防护
    { code: '01', name: '工作服' },
    { code: '02', name: '反光背心' },
    { code: '03', name: '防护服' },
    { code: '99', name: '其他身体防护' },
  ],
  'OP-05': [ // 防晒防暑用品
    { code: '01', name: '草帽' },
    { code: '02', name: '冰袖' },
    { code: '03', name: '防晒霜' },
    { code: '99', name: '其他防晒防暑用品' },
  ],
  'OP-06': [ // 日常劳动工具
    { code: '01', name: '修剪工具', description: '修枝剪、嫁接刀' },
    { code: '02', name: '手动农具', description: '锄头、铁锹、镰刀' },
    { code: '03', name: '测量工具' },
    { code: '99', name: '其他劳动工具' },
  ],
  'OP-07': [ // 小型电动工具
    { code: '01', name: '手持打药机' },
    { code: '02', name: '电锯' },
    { code: '03', name: '割草机' },
    { code: '99', name: '其他电动工具' },
  ],
  'OP-08': [ // 清洁工具
    { code: '01', name: '扫帚' },
    { code: '02', name: '水桶' },
    { code: '03', name: '清洁剂' },
    { code: '99', name: '其他清洁工具' },
  ],
  'OP-09': [ // 标识记录用品
    { code: '01', name: '田间标牌/标签' },
    { code: '02', name: '记录本/记号笔' },
    { code: '03', name: '二维码/RFID标签' },
    { code: '99', name: '其他标识记录用品' },
  ],

  // PH - 采后处理与流通
  'PH-01': [ // 采收容器
    { code: '01', name: '塑料周转箱' },
    { code: '02', name: '采摘篮/筐' },
    { code: '03', name: '吨袋/编织袋' },
    { code: '99', name: '其他采收容器' },
  ],
  'PH-02': [ // 包装材料
    { code: '01', name: '纸箱' },
    { code: '02', name: '泡沫网套/隔板' },
    { code: '03', name: '胶带/封口耗材' },
    { code: '04', name: '商品标签/追溯标签' },
    { code: '99', name: '其他包装材料' },
  ],
  'PH-03': [ // 冷链设备
    { code: '01', name: '预冷库/冷藏库' },
    { code: '02', name: '冷藏运输设备' },
    { code: '03', name: '保温箱/冰袋' },
    { code: '99', name: '其他冷链设备' },
  ],
  'PH-04': [ // 装卸仓储设备
    { code: '01', name: '手推车' },
    { code: '02', name: '托盘' },
    { code: '03', name: '小型运输车' },
    { code: '99', name: '其他装卸设备' },
  ],

  // IT - 数字化与管理
  'IT-01': [ // 监测设备
    { code: '01', name: '气象站' },
    { code: '02', name: '虫情测报灯' },
    { code: '03', name: '视频监控设备' },
    { code: '04', name: '土壤传感器' },
    { code: '99', name: '其他监测设备' },
  ],
  'IT-02': [ // 控制设备
    { code: '01', name: '环境参数感知设备' },
    { code: '02', name: '核心控制器' },
    { code: '03', name: '人机交互设备' },
    { code: '04', name: '通信与联网设备' },
    { code: '05', name: '电源与辅助控制设备' },
    { code: '99', name: '其他控制设备' },
  ],
  'IT-03': [ // 软件与服务
    { code: '01', name: 'ERP模块许可' },
    { code: '02', name: '数据分析服务' },
    { code: '03', name: '温室大棚控制系统Web' },
    { code: '04', name: '温室大棚控制系统小程序' },
    { code: '05', name: '数字农业软件服务' },
    { code: '99', name: '其他软件服务' },
  ],
  'IT-04': [ // 检测服务
    { code: '01', name: '土壤检测服务' },
    { code: '02', name: '水质检测服务' },
    { code: '03', name: '产品检测服务' },
    { code: '99', name: '其他检测服务' },
  ],
  'IT-05': [ // 手持检测设备
    { code: '01', name: '农残快检设备' },
    { code: '02', name: '手持式土壤检测仪' },
    { code: '03', name: '水分测定仪' },
    { code: '99', name: '其他手持检测设备' },
  ],

  // EC - 能源与通用耗材
  'EC-01': [ // 能源类
    { code: '01', name: '柴油/汽油' },
    { code: '02', name: '电力' },
    { code: '03', name: '太阳能板及配件' },
    { code: '04', name: '润滑油/润滑脂' },
    { code: '99', name: '其他能源' },
  ],
  'EC-02': [ // 通用耗材
    { code: '01', name: '电线电缆' },
    { code: '02', name: '扎带/螺丝/密封胶' },
    { code: '03', name: '电池' },
    { code: '99', name: '其他耗材' },
  ],

  // OT - 其他
  'OT-99': [
    { code: '01', name: '未分类资材' },
  ],

  // 默认小类
  'default': [
    { code: '01', name: '标准品' },
    { code: '02', name: '非标品' },
    { code: '03', name: '定制品' },
    { code: '99', name: '其他' },
  ],
};

// ==================== 采购商/供应商编码 ====================

// 供应商大类
export const supplierCategories = [
  { code: 'SU_SP', name: '种子与种苗类供应商', english: 'Seed & Plant Supplier', description: '种子、种苗、苗木等' },
  { code: 'SU_FE', name: '肥料与土壤改良类供应商', english: 'Fertilizer Supplier', description: '有机肥、化肥、土壤调理剂等' },
  { code: 'SU_PP', name: '农药与植保产品供应商', english: 'Pesticide Supplier', description: '杀虫剂、杀菌剂、除草剂等' },
  { code: 'SU_EQ', name: '农业机械与设备供应商', english: 'Equipment Supplier', description: '拖拉机、微耕机、收获机械等' },
  { code: 'SU_FA', name: '设施农业资材供应商', english: 'Facility Agriculture Supplier', description: '大棚/温室专用资材' },
  { code: 'SU_IR', name: '灌溉与水肥一体化供应商', english: 'Irrigation Supplier', description: '灌溉系统设备' },
  { code: 'SU_OP', name: '日常劳保与劳动工具供应商', english: 'Operations Support Supplier', description: '劳保用品、工具等' },
  { code: 'SU_PH', name: '仓储与物流资材供应商', english: 'Post-harvest Supplier', description: '采收容器、包装、冷链等' },
  { code: 'SU_TS', name: '检测与技术服务供应商', english: 'Technical Service Supplier', description: '检测服务、技术培训等' },
  { code: 'SU_UT', name: '能源与辅助耗材供应商', english: 'Energy Supplier', description: '能源、通用耗材等' },
  { code: 'SU_OT', name: '其他未分类供应商', english: 'Others Supplier', description: '临时合作、跨多类等' },
];

// 供应商中类（按大类分组）
export const supplierSubCategories: Record<string, Array<{ code: string; name: string; description?: string }>> = {
  'SU_SP': [ // 种子与种苗类供应商
    { code: '01', name: '粮食作物种子供应商' },
    { code: '02', name: '蔬菜种子/种苗供应商' },
    { code: '03', name: '水果苗木供应商' },
    { code: '04', name: '花卉与观赏植物供应商' },
    { code: '05', name: '食用菌/药用菌菌种供应商' },
    { code: '99', name: '其他种质资源供应商' },
  ],
  'SU_FE': [ // 肥料与土壤改良类供应商
    { code: '01', name: '有机肥供应商' },
    { code: '02', name: '化学肥料供应商' },
    { code: '03', name: '微生物菌剂/生物刺激素供应商' },
    { code: '04', name: '土壤调理剂供应商' },
    { code: '05', name: '育苗基质供应商' },
    { code: '99', name: '其他肥料类供应商' },
  ],
  'SU_PP': [ // 农药与植保产品供应商
    { code: '01', name: '杀虫剂供应商' },
    { code: '02', name: '杀菌剂供应商' },
    { code: '03', name: '除草剂供应商' },
    { code: '04', name: '植物生长调节剂供应商' },
    { code: '05', name: '绿色防控产品供应商' },
    { code: '06', name: '生物农药供应商' },
    { code: '99', name: '其他植保产品供应商' },
  ],
  'SU_EQ': [ // 农业机械与设备供应商
    { code: '01', name: '耕作与动力机械供应商' },
    { code: '02', name: '播种/移栽设备供应商' },
    { code: '03', name: '植保机械供应商' },
    { code: '04', name: '收获与采收机械供应商' },
    { code: '05', name: '初加工与分选设备供应商' },
    { code: '99', name: '其他农机设备供应商' },
  ],
  'SU_FA': [ // 设施农业资材供应商
    { code: '01', name: '温室/大棚骨架材料供应商' },
    { code: '02', name: '覆盖材料供应商' },
    { code: '03', name: '通风降温设备供应商' },
    { code: '04', name: '加温设备供应商' },
    { code: '05', name: '补光系统供应商' },
    { code: '06', name: '智能环控系统供应商' },
    { code: '99', name: '其他设施农业资材供应商' },
  ],
  'SU_IR': [ // 灌溉与水肥一体化供应商
    { code: '01', name: '水泵与水源设备供应商' },
    { code: '02', name: '输水管网供应商' },
    { code: '03', name: '过滤系统供应商' },
    { code: '04', name: '施肥装置供应商' },
    { code: '05', name: '灌溉终端供应商' },
    { code: '99', name: '其他灌溉设备供应商' },
  ],
  'SU_OP': [ // 日常劳保与劳动工具供应商
    { code: '01', name: '劳动防护用品供应商' },
    { code: '02', name: '日常手动工具供应商' },
    { code: '03', name: '小型电动工具供应商' },
    { code: '04', name: '清洁与卫生用品供应商' },
    { code: '99', name: '其他作业支持用品供应商' },
  ],
  'SU_PH': [ // 仓储与物流资材供应商
    { code: '01', name: '采收容器供应商' },
    { code: '02', name: '农产品包装材料供应商' },
    { code: '03', name: '冷链设备供应商' },
    { code: '04', name: '装卸与仓储设备供应商' },
    { code: '99', name: '其他采后处理供应商' },
  ],
  'SU_TS': [ // 检测与技术服务供应商
    { code: '01', name: '土壤/水质检测服务供应商' },
    { code: '02', name: '农残快检设备与试剂供应商' },
    { code: '03', name: '农业物联网设备供应商' },
    { code: '04', name: '农业技术咨询与培训服务商' },
    { code: '05', name: '数字农业软件服务商' },
    { code: '99', name: '其他技术服务供应商' },
  ],
  'SU_UT': [ // 能源与辅助耗材供应商
    { code: '01', name: '燃油/润滑油供应商' },
    { code: '02', name: '电力与新能源供应商' },
    { code: '03', name: '通用工业耗材供应商' },
    { code: '99', name: '其他能源与耗材供应商' },
  ],
  'SU_OT': [ // 其他未分类供应商
    { code: '99', name: '其他未分类供应商' },
  ],
};

// 供应商小类（按大类+中类分组）
export const supplierMinorCategories: Record<string, Array<{ code: string; name: string; description?: string }>> = {
  'SU_SP-01': [ // 粮食作物种子供应商
    { code: '01', name: '水稻种子供应商' },
    { code: '02', name: '小麦种子供应商' },
    { code: '03', name: '玉米种子供应商' },
    { code: '99', name: '其他粮食作物种子供应商' },
  ],
  'SU_SP-02': [ // 蔬菜种子/种苗供应商
    { code: '01', name: '叶菜类种子供应商' },
    { code: '02', name: '茄果类种子供应商' },
    { code: '03', name: '瓜类种子供应商' },
    { code: '04', name: '蔬菜种苗供应商' },
    { code: '99', name: '其他蔬菜种子供应商' },
  ],
  'SU_SP-03': [ // 水果苗木供应商
    { code: '01', name: '柑橘苗木供应商' },
    { code: '02', name: '苹果苗木供应商' },
    { code: '03', name: '葡萄苗木供应商' },
    { code: '04', name: '浆果苗木供应商' },
    { code: '99', name: '其他水果苗木供应商' },
  ],
  
  'SU_FE-01': [ // 有机肥供应商
    { code: '01', name: '农家肥供应商' },
    { code: '02', name: '商品有机肥供应商' },
    { code: '03', name: '生物有机肥供应商' },
    { code: '99', name: '其他有机肥供应商' },
  ],
  'SU_FE-02': [ // 化学肥料供应商
    { code: '01', name: '氮肥供应商' },
    { code: '02', name: '磷肥供应商' },
    { code: '03', name: '钾肥供应商' },
    { code: '04', name: '复合肥供应商' },
    { code: '05', name: '水溶肥供应商' },
    { code: '99', name: '其他化肥供应商' },
  ],
  'SU_FE-03': [ // 微生物菌剂供应商
    { code: '01', name: '根瘤菌剂供应商' },
    { code: '02', name: '固氮菌剂供应商' },
    { code: '03', name: '解磷解钾菌剂供应商' },
    { code: '04', name: '芽孢杆菌剂供应商' },
    { code: '99', name: '其他微生物菌剂供应商' },
  ],
  
  'SU_PP-01': [ // 杀虫剂供应商
    { code: '01', name: '有机磷类杀虫剂供应商' },
    { code: '02', name: '菊酯类杀虫剂供应商' },
    { code: '03', name: '新烟碱类杀虫剂供应商' },
    { code: '04', name: '生物杀虫剂供应商' },
    { code: '99', name: '其他杀虫剂供应商' },
  ],
  'SU_PP-02': [ // 杀菌剂供应商
    { code: '01', name: '保护性杀菌剂供应商' },
    { code: '02', name: '内吸性杀菌剂供应商' },
    { code: '03', name: '生物杀菌剂供应商' },
    { code: '99', name: '其他杀菌剂供应商' },
  ],
  'SU_PP-03': [ // 除草剂供应商
    { code: '01', name: '选择性除草剂供应商' },
    { code: '02', name: '灭生性除草剂供应商' },
    { code: '99', name: '其他除草剂供应商' },
  ],
  
  'SU_EQ-01': [ // 耕作与动力机械供应商
    { code: '01', name: '拖拉机供应商' },
    { code: '02', name: '微耕机供应商' },
    { code: '03', name: '旋耕机供应商' },
    { code: '99', name: '其他耕作机械供应商' },
  ],
  'SU_EQ-03': [ // 植保机械供应商
    { code: '01', name: '喷雾机供应商' },
    { code: '02', name: '植保无人机供应商' },
    { code: '99', name: '其他植保机械供应商' },
  ],
  
  'SU_FA-01': [ // 温室/大棚骨架材料供应商
    { code: '01', name: '镀锌管供应商' },
    { code: '02', name: '铝合金骨架供应商' },
    { code: '99', name: '其他骨架材料供应商' },
  ],
  'SU_FA-02': [ // 覆盖材料供应商
    { code: '01', name: 'PO膜供应商' },
    { code: '02', name: '防虫网供应商' },
    { code: '03', name: '遮阳网供应商' },
    { code: '99', name: '其他覆盖材料供应商' },
  ],
  
  'SU_IR-01': [ // 水泵与水源设备供应商
    { code: '01', name: '水泵供应商' },
    { code: '02', name: '水源设备供应商' },
    { code: '99', name: '其他水源设备供应商' },
  ],
  'SU_IR-02': [ // 输水管网供应商
    { code: '01', name: 'PVC管材供应商' },
    { code: '02', name: 'PE管材供应商' },
    { code: '99', name: '其他管材供应商' },
  ],
  
  'default': [
    { code: '01', name: '一级供应商' },
    { code: '02', name: '二级供应商' },
    { code: '99', name: '其他' },
  ],
};

// ==================== 编码规则说明 ====================

export const encodingRules = {
  material: {
    structure: '大类(2位字母) + 中类(2位数字) + 小类(2位数字) + 顺序号(3位数字)',
    example: 'SP0101001',
    description: '资材编码采用层级分类方式，支持多级检索和统计分析',
    exampleDetail: '生产投入类 > 种质资源 > 粮食作物种子 > 水稻种子',
  },
  supplier: {
    structure: '前缀(SU_) + 大类(2位字母) + 中类(2位数字) + 小类(2位数字) + 顺序号(3位数字)',
    example: 'SU_SP01001',
    description: '供应商编码以SU开头，后接具体分类编码',
    exampleDetail: '种子与种苗类供应商 > 粮食作物种子 > 水稻',
  },
};

// ==================== 辅助函数 ====================

// 获取小类列表
export function getMaterialMinorCategories(mainCode: string, subCode: string) {
  const key = `${mainCode}-${subCode}`;
  return materialMinorCategories[key] || materialMinorCategories['default'];
}

export function getSupplierMinorCategories(mainCode: string, subCode: string) {
  const key = `${mainCode}-${subCode}`;
  return supplierMinorCategories[key] || supplierMinorCategories['default'];
}

// 解析编码
export function parseMaterialCode(code: string) {
  if (!code || code.length < 9) return null;
  
  const mainCode = code.substring(0, 2);
  const subCode = code.substring(2, 4);
  const minorCode = code.substring(4, 6);
  const seq = code.substring(6);
  
  const main = materialCategories.find(c => c.code === mainCode);
  const sub = materialSubCategories[mainCode]?.find(c => c.code === subCode);
  const minor = getMaterialMinorCategories(mainCode, subCode).find(c => c.code === minorCode);
  
  return {
    mainCode,
    subCode,
    minorCode,
    seq,
    main,
    sub,
    minor,
    isValid: !!main && !!sub && !!minor,
  };
}

export function parseSupplierCode(code: string) {
  if (!code || code.length < 11 || !code.startsWith('SU_')) return null;
  
  const mainCode = code.substring(0, 5); // SU_XX
  const subCode = code.substring(5, 7);
  const minorCode = code.substring(7, 9);
  const seq = code.substring(9);
  
  const main = supplierCategories.find(c => c.code === mainCode);
  const sub = supplierSubCategories[mainCode]?.find(c => c.code === subCode);
  const minor = getSupplierMinorCategories(mainCode, subCode).find(c => c.code === minorCode);
  
  return {
    mainCode,
    subCode,
    minorCode,
    seq,
    main,
    sub,
    minor,
    isValid: !!main && !!sub && !!minor,
  };
}
